import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ArrowUpRight,
  DollarSign,
  ShoppingBag,
  Users,
  TrendingUp,
  Sparkles,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from "recharts";
import { aiInsights, customerGrowth, monthlySales, revenueTrend } from "@/lib/mock-data";

export const Route = createFileRoute("/")({
  component: Index,
});

const metrics = [
  { label: "Total Revenue", value: "$1.02M", delta: "+18.2%", icon: DollarSign },
  { label: "Orders", value: "12,480", delta: "+9.4%", icon: ShoppingBag },
  { label: "Customers", value: "5,240", delta: "+12.1%", icon: Users },
  { label: "Conversion Rate", value: "4.82%", delta: "+0.6pp", icon: TrendingUp },
];

function Index() {
  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Dashboard <span className="gradient-text">Overview</span>
          </h1>
          <p className="text-sm text-muted-foreground">Realtime signals across store, leads, and AI activity.</p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {metrics.map((m) => (
            <Card key={m.label} className="glass-card border-0">
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-xs font-medium text-muted-foreground">{m.label}</div>
                    <div className="mt-1 text-2xl font-bold">{m.value}</div>
                    <div className="mt-2 flex items-center gap-1 text-xs font-semibold text-emerald-600">
                      <ArrowUpRight className="h-3 w-3" /> {m.delta}
                    </div>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg gradient-primary text-white">
                    <m.icon className="h-5 w-5" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <Card className="glass-card border-0 lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base">Monthly Sales</CardTitle>
            </CardHeader>
            <CardContent className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlySales}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" fontSize={12} />
                  <YAxis fontSize={12} />
                  <RTooltip />
                  <Bar dataKey="sales" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="glass-card border-0">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <Sparkles className="h-4 w-4 text-primary" />
                AI Insights
              </CardTitle>
              <Badge className="gradient-primary text-white">4 new</Badge>
            </CardHeader>
            <CardContent className="space-y-3">
              {aiInsights.map((i) => (
                <div key={i.title} className="rounded-xl border bg-white/60 p-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-semibold">{i.title}</div>
                    <Badge variant={i.severity === "high" ? "default" : "secondary"} className="text-[10px]">
                      {i.severity}
                    </Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{i.detail}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Card className="glass-card border-0">
            <CardHeader>
              <CardTitle className="text-base">Customer Growth</CardTitle>
            </CardHeader>
            <CardContent className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={customerGrowth}>
                  <defs>
                    <linearGradient id="gc" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.6} />
                      <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" fontSize={12} />
                  <YAxis fontSize={12} />
                  <RTooltip />
                  <Area type="monotone" dataKey="customers" stroke="var(--color-primary)" strokeWidth={2} fill="url(#gc)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          <Card className="glass-card border-0">
            <CardHeader>
              <CardTitle className="text-base">Revenue Trend vs Projection</CardTitle>
            </CardHeader>
            <CardContent className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" fontSize={12} />
                  <YAxis fontSize={12} />
                  <RTooltip />
                  <Line type="monotone" dataKey="revenue" stroke="var(--color-primary)" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="projected" stroke="var(--color-chart-4)" strokeDasharray="5 5" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
