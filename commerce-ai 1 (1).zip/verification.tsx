import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, ShieldAlert } from "lucide-react";

export const Route = createFileRoute("/verification")({ component: Verification });

function Verification() {
  const [form, setForm] = useState({ business: "", gst: "", pan: "", address: "" });
  const [result, setResult] = useState<{ trust: number; risk: string; confidence: number } | null>(null);

  const verify = () => {
    const filled = Object.values(form).filter(Boolean).length;
    const trust = Math.min(98, 55 + filled * 10 + (form.gst.length > 10 ? 8 : 0));
    const risk = trust > 85 ? "Low" : trust > 70 ? "Medium" : "High";
    const confidence = Math.min(99, trust + 2);
    setResult({ trust, risk, confidence });
  };

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight"><span className="gradient-text">Seller</span> Verification</h1>
          <p className="text-sm text-muted-foreground">AI-powered trust scoring for merchant onboarding.</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="glass-card border-0">
            <CardHeader><CardTitle>Business details</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1"><Label>Business name</Label><Input value={form.business} onChange={(e) => setForm({ ...form, business: e.target.value })} /></div>
              <div className="space-y-1"><Label>GST number</Label><Input value={form.gst} onChange={(e) => setForm({ ...form, gst: e.target.value })} placeholder="22AAAAA0000A1Z5" /></div>
              <div className="space-y-1"><Label>PAN number</Label><Input value={form.pan} onChange={(e) => setForm({ ...form, pan: e.target.value })} placeholder="ABCDE1234F" /></div>
              <div className="space-y-1"><Label>Registered address</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
              <Button className="w-full gradient-primary text-white" onClick={verify} disabled={!form.business}>
                Run AI verification
              </Button>
            </CardContent>
          </Card>

          <Card className="glass-card border-0">
            <CardHeader><CardTitle>Trust report</CardTitle></CardHeader>
            <CardContent>
              {!result ? (
                <p className="py-16 text-center text-sm text-muted-foreground">Submit details to generate a trust report.</p>
              ) : (
                <div className="space-y-5">
                  <div className="flex items-center justify-center">
                    <div className="relative flex h-40 w-40 items-center justify-center rounded-full gradient-primary text-white shadow-xl">
                      <div className="text-center">
                        <div className="text-4xl font-bold">{result.trust}</div>
                        <div className="text-xs uppercase tracking-wide opacity-80">AI Trust Score</div>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-center">
                    {result.risk === "Low" ? (
                      <Badge className="gap-1 bg-emerald-100 text-emerald-700"><ShieldCheck className="h-3 w-3" /> Verified Seller</Badge>
                    ) : (
                      <Badge className="gap-1 bg-amber-100 text-amber-700"><ShieldAlert className="h-3 w-3" /> Review recommended</Badge>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-xl border bg-white/60 p-3">
                      <div className="text-xs text-muted-foreground">Risk level</div>
                      <div className="text-lg font-bold">{result.risk}</div>
                    </div>
                    <div className="rounded-xl border bg-white/60 p-3">
                      <div className="text-xs text-muted-foreground">Business confidence</div>
                      <div className="text-lg font-bold">{result.confidence}%</div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}