export type Product = {
  id: string;
  name: string;
  price: number;
  rating: number;
  stock: number;
  category: string;
  image: string;
  description: string;
};

const img = (seed: string) =>
  `https://picsum.photos/seed/${seed}/600/400`;

export const products: Product[] = [
  { id: "p1", name: "Wireless Noise-Cancelling Headphones", price: 249, rating: 4.7, stock: 42, category: "Electronics", image: img("headphones"), description: "Immersive sound with 40h battery life." },
  { id: "p2", name: "Smart Fitness Watch Pro", price: 199, rating: 4.5, stock: 88, category: "Electronics", image: img("watch"), description: "Heart-rate, GPS, and AI coaching." },
  { id: "p3", name: "Ergonomic Office Chair", price: 389, rating: 4.6, stock: 15, category: "Furniture", image: img("chair"), description: "Lumbar support with breathable mesh." },
  { id: "p4", name: "Ultralight Laptop 14\"", price: 1299, rating: 4.8, stock: 22, category: "Electronics", image: img("laptop"), description: "M-series performance, all-day battery." },
  { id: "p5", name: "Premium Coffee Beans 1kg", price: 34, rating: 4.9, stock: 210, category: "Grocery", image: img("coffee"), description: "Single-origin, medium roast." },
  { id: "p6", name: "Minimalist Leather Wallet", price: 79, rating: 4.4, stock: 130, category: "Accessories", image: img("wallet"), description: "Full-grain leather, RFID-safe." },
  { id: "p7", name: "Yoga Mat Pro Grip", price: 59, rating: 4.6, stock: 76, category: "Fitness", image: img("yoga"), description: "Non-slip, eco-friendly TPE." },
  { id: "p8", name: "4K Action Camera", price: 329, rating: 4.5, stock: 34, category: "Electronics", image: img("camera"), description: "Waterproof with stabilization." },
  { id: "p9", name: "Aromatic Candle Set", price: 45, rating: 4.7, stock: 190, category: "Home", image: img("candle"), description: "Hand-poured soy wax, 3-pack." },
  { id: "p10", name: "Running Shoes Cloud X", price: 149, rating: 4.6, stock: 60, category: "Fitness", image: img("shoes"), description: "Featherlight cushioning." },
  { id: "p11", name: "Stainless Insulated Bottle", price: 29, rating: 4.8, stock: 300, category: "Accessories", image: img("bottle"), description: "24h cold, 12h hot." },
  { id: "p12", name: "Standing Desk Electric", price: 499, rating: 4.5, stock: 12, category: "Furniture", image: img("desk"), description: "Motorised, memory presets." },
];

export const categories = ["All", ...Array.from(new Set(products.map((p) => p.category)))];

export type Lead = {
  id: string;
  name: string;
  email: string;
  phone: string;
  product: string;
  status: "New" | "Warm" | "Hot" | "Converted";
  score: number;
};

export const initialLeads: Lead[] = [
  { id: "l1", name: "Ava Thompson", email: "ava@brightco.io", phone: "+1 555 0142", product: "Ultralight Laptop 14\"", status: "Hot", score: 92 },
  { id: "l2", name: "Marcus Chen", email: "marcus@nova.dev", phone: "+1 555 0187", product: "Wireless Noise-Cancelling Headphones", status: "Warm", score: 74 },
  { id: "l3", name: "Priya Sharma", email: "priya@lumen.ai", phone: "+91 98211 44210", product: "Smart Fitness Watch Pro", status: "New", score: 41 },
  { id: "l4", name: "Diego Martins", email: "diego@velocity.co", phone: "+55 11 94555 2201", product: "Ergonomic Office Chair", status: "Converted", score: 100 },
  { id: "l5", name: "Sara O'Neil", email: "sara@northshore.com", phone: "+353 87 445 1290", product: "Standing Desk Electric", status: "Hot", score: 88 },
  { id: "l6", name: "Kenji Watanabe", email: "kenji@atlas.jp", phone: "+81 90 1234 5678", product: "4K Action Camera", status: "Warm", score: 66 },
];

export const monthlySales = [
  { month: "Jan", sales: 42000 }, { month: "Feb", sales: 51000 }, { month: "Mar", sales: 48000 },
  { month: "Apr", sales: 61000 }, { month: "May", sales: 72000 }, { month: "Jun", sales: 68000 },
  { month: "Jul", sales: 81000 }, { month: "Aug", sales: 95000 }, { month: "Sep", sales: 88000 },
  { month: "Oct", sales: 102000 }, { month: "Nov", sales: 118000 }, { month: "Dec", sales: 134000 },
];

export const customerGrowth = [
  { month: "Jan", customers: 1200 }, { month: "Feb", customers: 1420 }, { month: "Mar", customers: 1610 },
  { month: "Apr", customers: 1890 }, { month: "May", customers: 2180 }, { month: "Jun", customers: 2510 },
  { month: "Jul", customers: 2890 }, { month: "Aug", customers: 3320 }, { month: "Sep", customers: 3720 },
  { month: "Oct", customers: 4180 }, { month: "Nov", customers: 4690 }, { month: "Dec", customers: 5240 },
];

export const revenueTrend = monthlySales.map((m) => ({ month: m.month, revenue: m.sales, projected: Math.round(m.sales * 1.15) }));

export const aiInsights = [
  { title: "Recover 34 abandoned carts", detail: "Send personalised discount to boost recovery by ~22%.", severity: "high" as const },
  { title: "Follow up 12 hot leads", detail: "Leads scored >85 are 4x more likely to close this week.", severity: "high" as const },
  { title: "Promote trending: Fitness Watch Pro", detail: "Views up 48% — feature in homepage hero.", severity: "medium" as const },
  { title: "Restock Standing Desk Electric", detail: "Only 12 units left; velocity suggests stockout in 6 days.", severity: "medium" as const },
];