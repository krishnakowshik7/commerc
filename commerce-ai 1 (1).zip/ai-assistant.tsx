import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState, useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bot, Send, Sparkles, User } from "lucide-react";

export const Route = createFileRoute("/ai-assistant")({ component: AIAssistant });

type Msg = { role: "user" | "assistant"; content: string };

const suggestedPrompts = [
  "Recommend a laptop for a remote designer",
  "How can I improve my store conversion rate?",
  "Draft a follow-up email for a hot lead",
  "What's trending in my category this week?",
];

// Gemini API integration placeholder — wire your Gemini key here
async function askGemini(prompt: string, _history: Msg[]): Promise<string> {
  // TODO: replace with real fetch to Gemini API using GEMINI_API_KEY
  // const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + KEY, {...})
  await new Promise((r) => setTimeout(r, 700));
  const low = prompt.toLowerCase();
  if (low.includes("laptop")) return "For a remote designer, I'd recommend the Ultralight Laptop 14\" — great colour accuracy, all-day battery, and quiet under load. Want me to add it to a quote?";
  if (low.includes("conversion")) return "Three quick wins: (1) surface reviews on product pages, (2) simplify checkout to one step, (3) add abandoned-cart nudges within 30 min. Expected lift: +8–14%.";
  if (low.includes("email") || low.includes("lead")) return "Subject: Following up on your interest\n\nHi {{name}}, quick note — I noticed you were looking at {{product}}. Happy to answer any questions or arrange a live demo this week.";
  return "Here's a thoughtful, on-brand response. (Connect Gemini API to enable live answers.)";
}

function AIAssistant() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi! I'm your CommerceFlow AI assistant. Ask about products, leads, or strategy." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    const next: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);
    const reply = await askGemini(text, next);
    setMessages([...next, { role: "assistant", content: reply }]);
    setLoading(false);
  };

  return (
    <AppShell>
      <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-4xl flex-col space-y-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Sparkles className="h-7 w-7 text-primary" />
            <span className="gradient-text">AI</span> Assistant
          </h1>
          <p className="text-sm text-muted-foreground">Chat with Gemini-powered commerce intelligence.</p>
        </div>

        <Card className="glass-card flex flex-1 flex-col overflow-hidden border-0">
          <CardContent ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto p-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-3 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
                <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${m.role === "user" ? "bg-muted" : "gradient-primary"}`}>
                  {m.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4 text-white" />}
                </div>
                <div className={`max-w-[80%] whitespace-pre-wrap rounded-2xl px-4 py-2 text-sm ${m.role === "user" ? "gradient-primary text-white" : "bg-white/70 backdrop-blur"}`}>
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full gradient-primary">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="rounded-2xl bg-white/70 px-4 py-2 text-sm text-muted-foreground backdrop-blur">Thinking...</div>
              </div>
            )}
          </CardContent>
          <div className="border-t bg-white/40 p-3 backdrop-blur">
            <div className="mb-2 flex flex-wrap gap-2">
              {suggestedPrompts.map((p) => (
                <button key={p} onClick={() => send(p)} className="rounded-full border bg-white/60 px-3 py-1 text-xs hover:bg-white">
                  {p}
                </button>
              ))}
            </div>
            <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex gap-2">
              <Input placeholder="Ask anything..." value={input} onChange={(e) => setInput(e.target.value)} />
              <Button type="submit" className="gradient-primary text-white" disabled={loading}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}