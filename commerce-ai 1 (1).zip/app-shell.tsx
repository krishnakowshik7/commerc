import type { ReactNode } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./app-sidebar";
import { CartProvider, useCart } from "@/lib/cart-store";
import { Button } from "@/components/ui/button";
import { Bell, ShoppingCart } from "lucide-react";
import { CartDrawer } from "./cart-drawer";

function HeaderCart() {
  const { count, setOpen } = useCart();
  return (
    <Button variant="ghost" size="sm" className="relative" onClick={() => setOpen(true)}>
      <ShoppingCart className="h-5 w-5" />
      {count > 0 && (
        <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full gradient-primary px-1 text-[10px] font-bold text-white">
          {count}
        </span>
      )}
    </Button>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <CartProvider>
      <SidebarProvider>
        <div className="flex min-h-screen w-full bg-gradient-to-br from-blue-50 via-white to-indigo-50">
          <AppSidebar />
          <div className="flex flex-1 flex-col">
            <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b bg-white/60 px-4 backdrop-blur-lg">
              <div className="flex items-center gap-2">
                <SidebarTrigger />
                <span className="hidden text-sm font-medium text-muted-foreground md:inline">
                  Welcome back — here's what's happening today.
                </span>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm">
                  <Bell className="h-5 w-5" />
                </Button>
                <HeaderCart />
                <div className="ml-2 flex h-9 w-9 items-center justify-center rounded-full gradient-primary text-sm font-bold text-white">
                  JS
                </div>
              </div>
            </header>
            <main className="flex-1 p-4 md:p-6">{children}</main>
          </div>
          <CartDrawer />
        </div>
      </SidebarProvider>
    </CartProvider>
  );
}