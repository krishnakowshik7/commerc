import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Copy, Eye, EyeOff } from "lucide-react";

export const Route = createFileRoute("/settings")({ component: Settings });

function Settings() {
  const [dark, setDark] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const apiKey = "sk_live_cf_ai_••••••••4a29";

  const toggleDark = (v: boolean) => {
    setDark(v);
    document.documentElement.classList.toggle("dark", v);
  };

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight"><span className="gradient-text">Settings</span></h1>
          <p className="text-sm text-muted-foreground">Manage your workspace preferences.</p>
        </div>

        <Tabs defaultValue="profile" className="space-y-4">
          <TabsList>
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="api">API Keys</TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <Card className="glass-card border-0">
              <CardHeader><CardTitle>Profile</CardTitle></CardHeader>
              <CardContent className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1"><Label>Full name</Label><Input defaultValue="Jane Smith" /></div>
                <div className="space-y-1"><Label>Email</Label><Input defaultValue="jane@commerceflow.ai" /></div>
                <div className="space-y-1"><Label>Company</Label><Input defaultValue="CommerceFlow AI" /></div>
                <div className="space-y-1"><Label>Role</Label><Input defaultValue="Founder" /></div>
                <div className="sm:col-span-2"><Button className="gradient-primary text-white" onClick={() => toast.success("Profile saved")}>Save changes</Button></div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <Card className="glass-card border-0">
              <CardHeader><CardTitle>Notifications</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                {["Order alerts", "New lead notifications", "Weekly AI insights digest", "Product review pings"].map((n) => (
                  <div key={n} className="flex items-center justify-between rounded-xl border bg-white/60 p-3">
                    <span className="text-sm font-medium">{n}</span>
                    <Switch defaultChecked />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="appearance">
            <Card className="glass-card border-0">
              <CardHeader><CardTitle>Appearance</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between rounded-xl border bg-white/60 p-3">
                  <div>
                    <div className="text-sm font-medium">Dark mode</div>
                    <div className="text-xs text-muted-foreground">Switch to a low-light theme.</div>
                  </div>
                  <Switch checked={dark} onCheckedChange={toggleDark} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api">
            <Card className="glass-card border-0">
              <CardHeader><CardTitle>API Keys</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1">
                  <Label>Gemini API key</Label>
                  <div className="flex gap-2">
                    <Input type={showKey ? "text" : "password"} defaultValue="AIzaSy••••••••••••••••••••" />
                    <Button variant="outline" size="icon" onClick={() => setShowKey((v) => !v)}>
                      {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                <div className="space-y-1">
                  <Label>CommerceFlow secret</Label>
                  <div className="flex gap-2">
                    <Input readOnly value={apiKey} />
                    <Button variant="outline" size="icon" onClick={() => { navigator.clipboard.writeText(apiKey); toast.success("Copied"); }}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <Button className="gradient-primary text-white" onClick={() => toast.success("API keys saved")}>Save keys</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  );
}