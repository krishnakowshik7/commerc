import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { categories, products, type Product } from "@/lib/mock-data";
import { useCart } from "@/lib/cart-store";
import { Search, Star, Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/store")({ component: StorePage });

function ProductCard({ p }: { p: Product }) {
  const { add, setOpen } = useCart();
  return (
    <Card className="glass-card overflow-hidden border-0 transition hover:-translate-y-1 hover:shadow-xl">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img src={p.image} alt={p.name} className="h-full w-full object-cover transition duration-500 hover:scale-105" />
        <Badge className="absolute left-2 top-2 bg-white/80 text-foreground backdrop-blur">{p.category}</Badge>
      </div>
      <CardContent className="space-y-2 p-4">
        <div className="line-clamp-1 font-semibold">{p.name}</div>
        <p className="line-clamp-2 text-xs text-muted-foreground">{p.description}</p>
        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center gap-1 text-amber-500">
            <Star className="h-3 w-3 fill-amber-500" />
            <span className="font-semibold">{p.rating}</span>
          </span>
          <span className={p.stock < 20 ? "text-destructive" : "text-muted-foreground"}>
            {p.stock} in stock
          </span>
        </div>
        <div className="flex items-center justify-between pt-1">
          <div className="text-lg font-bold gradient-text">${p.price}</div>
          <Button
            size="sm"
            className="gradient-primary text-white"
            onClick={() => {
              add(p);
              toast.success(`${p.name} added to cart`);
              setOpen(true);
            }}
          >
            <Plus className="mr-1 h-3 w-3" /> Add
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function StorePage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");

  const filtered = useMemo(
    () =>
      products.filter(
        (p) =>
          (cat === "All" || p.category === cat) &&
          p.name.toLowerCase().includes(q.toLowerCase()),
      ),
    [q, cat],
  );

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            <span className="gradient-text">Store</span> Catalog
          </h1>
          <p className="text-sm text-muted-foreground">Browse products and add them to your cart.</p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search products..." className="pl-9" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger className="sm:w-56">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((p) => <ProductCard key={p.id} p={p} />)}
        </div>
        {filtered.length === 0 && (
          <p className="py-16 text-center text-muted-foreground">No products match your search.</p>
        )}
      </div>
    </AppShell>
  );
}