import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Printer } from "lucide-react";

export const Route = createFileRoute("/quotes")({ component: Quotes });

type Quote = {
  company: string; product: string; quantity: number; location: string;
  unitPrice: number; discount: number; total: number; delivery: string;
};

function Quotes() {
  const [form, setForm] = useState({ company: "", product: "", quantity: 10, location: "" });
  const [quote, setQuote] = useState<Quote | null>(null);

  const generate = () => {
    const unit = 199 + (form.product.length * 3);
    const discount = form.quantity > 100 ? 0.18 : form.quantity > 50 ? 0.12 : 0.05;
    const total = unit * form.quantity * (1 - discount);
    const delivery = form.location.toLowerCase().includes("us") ? "5–7 business days" : "10–14 business days";
    setQuote({ ...form, unitPrice: unit, discount, total, delivery });
  };

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight"><span className="gradient-text">B2B</span> Quotes</h1>
          <p className="text-sm text-muted-foreground">Generate instant, AI-priced quotations for bulk orders.</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="glass-card border-0">
            <CardHeader><CardTitle>Quote request</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1"><Label>Company name</Label><Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} placeholder="Acme Corp" /></div>
              <div className="space-y-1"><Label>Product</Label><Input value={form.product} onChange={(e) => setForm({ ...form, product: e.target.value })} placeholder="Wireless Headphones" /></div>
              <div className="space-y-1"><Label>Quantity</Label><Input type="number" min={1} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} /></div>
              <div className="space-y-1"><Label>Delivery location</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="New York, USA" /></div>
              <Button className="w-full gradient-primary text-white" onClick={generate} disabled={!form.company || !form.product}>
                Generate Quote
              </Button>
            </CardContent>
          </Card>

          <Card className="glass-card border-0 print:shadow-none">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5" /> Quotation</CardTitle>
              {quote && (
                <Button size="sm" variant="outline" onClick={() => window.print()}><Printer className="mr-1 h-4 w-4" /> Print</Button>
              )}
            </CardHeader>
            <CardContent>
              {!quote ? (
                <p className="py-16 text-center text-sm text-muted-foreground">Fill the form to generate a quote.</p>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-muted-foreground">Prepared for</div>
                      <div className="text-lg font-bold">{quote.company}</div>
                    </div>
                    <Badge className="gradient-primary text-white">Valid 30 days</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-3 rounded-xl border bg-white/60 p-4">
                    <div><div className="text-xs text-muted-foreground">Product</div><div className="font-semibold">{quote.product}</div></div>
                    <div><div className="text-xs text-muted-foreground">Quantity</div><div className="font-semibold">{quote.quantity}</div></div>
                    <div><div className="text-xs text-muted-foreground">Unit price</div><div className="font-semibold">${quote.unitPrice.toFixed(2)}</div></div>
                    <div><div className="text-xs text-muted-foreground">Discount</div><div className="font-semibold text-emerald-600">{(quote.discount * 100).toFixed(0)}%</div></div>
                    <div><div className="text-xs text-muted-foreground">Delivery to</div><div className="font-semibold">{quote.location}</div></div>
                    <div><div className="text-xs text-muted-foreground">Delivery time</div><div className="font-semibold">{quote.delivery}</div></div>
                  </div>
                  <div className="rounded-xl gradient-primary p-4 text-white">
                    <div className="text-xs opacity-80">Estimated total</div>
                    <div className="text-3xl font-bold">${quote.total.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}