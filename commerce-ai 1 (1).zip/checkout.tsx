import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart-store";
import { toast } from "sonner";

export const Route = createFileRoute("/checkout")({ component: Checkout });

function Checkout() {
  const { items, total, clear } = useCart();
  const navigate = useNavigate();

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl space-y-6">
        <h1 className="text-3xl font-bold">Checkout</h1>
        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="glass-card border-0 lg:col-span-2">
            <CardHeader><CardTitle>Shipping details</CardTitle></CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1"><Label>Full name</Label><Input placeholder="Jane Smith" /></div>
              <div className="space-y-1"><Label>Email</Label><Input placeholder="jane@company.com" /></div>
              <div className="space-y-1 sm:col-span-2"><Label>Address</Label><Input placeholder="123 Market St" /></div>
              <div className="space-y-1"><Label>City</Label><Input placeholder="San Francisco" /></div>
              <div className="space-y-1"><Label>Postal code</Label><Input placeholder="94103" /></div>
              <div className="space-y-1 sm:col-span-2"><Label>Card number</Label><Input placeholder="4242 4242 4242 4242" /></div>
            </CardContent>
          </Card>
          <Card className="glass-card h-fit border-0">
            <CardHeader><CardTitle>Order summary</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {items.length === 0 ? (
                <p className="text-sm text-muted-foreground">No items in cart.</p>
              ) : items.map((i) => (
                <div key={i.product.id} className="flex justify-between text-sm">
                  <span className="line-clamp-1 pr-2">{i.product.name} × {i.qty}</span>
                  <span className="font-semibold">${(i.product.price * i.qty).toFixed(2)}</span>
                </div>
              ))}
              <div className="flex justify-between border-t pt-3 text-base font-bold">
                <span>Total</span><span>${total.toFixed(2)}</span>
              </div>
              <Button
                className="w-full gradient-primary text-white"
                disabled={items.length === 0}
                onClick={() => {
                  toast.success("Order placed! (demo)");
                  clear();
                  navigate({ to: "/store" });
                }}
              >
                Place order
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}